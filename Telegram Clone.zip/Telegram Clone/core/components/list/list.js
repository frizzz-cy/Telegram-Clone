export default {
  name: 'list'
};