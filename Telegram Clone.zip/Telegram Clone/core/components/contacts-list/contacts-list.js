export default {
  name: 'contactsList'
};