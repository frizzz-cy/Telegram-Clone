export default {
  name: 'icon'
};