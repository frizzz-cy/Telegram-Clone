export default {
  name: 'chip'
};