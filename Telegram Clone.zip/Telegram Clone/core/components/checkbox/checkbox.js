export default {
  name: 'checkbox'
};